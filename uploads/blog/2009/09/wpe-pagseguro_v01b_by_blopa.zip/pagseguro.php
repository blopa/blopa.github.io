<?php
$_GET["sessionid"] = $_GET["sessionid"]=="" ? $_SESSION["pagseguro_id"] : $_GET["sessionid"];
require_once("pagseguro/pgs.php");
require_once("pagseguro/tratadados.php");

$nzshpcrt_gateways[$num]['name'] = 'Manual Payment';
$nzshpcrt_gateways[$num]['admin_name'] = 'PagSeguro';
$nzshpcrt_gateways[$num]['internalname'] = 'pagseguro';
$nzshpcrt_gateways[$num]['function'] = 'gateway_pagseguro';
$nzshpcrt_gateways[$num]['form'] = "form_pagseguro";
$nzshpcrt_gateways[$num]['submit_function'] = "submit_pagseguro";

//echo "http://".$_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
//phpinfo();
if( get_option('transact_url')=="http://".$_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"]){ transact_url();}

function gateway_pagseguro($seperator, $sessionid) {
	global $wpdb;
	$transact_url = get_option('transact_url');

	$purchase_log = $wpdb->get_row("SELECT * FROM `wp_wpsc_purchase_logs` WHERE `sessionid`= ".$sessionid." LIMIT 1",ARRAY_A) ;
	$cart_sql = "SELECT * FROM `wp_wpsc_cart_contents` WHERE `purchaseid`='".$purchase_log['id']."'";
	$cart = $wpdb->get_results($cart_sql,ARRAY_A) ;

	//$options = array("email_cobranca" => get_option('pagseguro_business'),"ref_transacao" => $purchase_log['id']);
	$options = array("email_cobranca" => get_option('pagseguro_email'),"ref_transacao" => $purchase_log['id'],"encoding" => get_bloginfo('charset') );
	$psg = New pgs($options);

	foreach((array)$cart as $item)
	{
		$product_data = $wpdb->get_results("SELECT * FROM `wp_wpsc_product_list` WHERE `id`='".$item['prodid']."' LIMIT 1",ARRAY_A);
		$product_data = $product_data[0];

		$produtos = array("id" => uniqid($item['id']),
		"descricao" => urlencode(stripslashes($product_data['name']).stripslashes($variation_list)),
		"quantidade" => $item['quantity'],
		"peso" => $item['weight'],
		"valor" => $item['price']);

		//var_dump($produtos);

		$psg->adicionar($produtos);
	}

	$cliente = array (
		  'nome'   => $_POST["collected_data"][2] . " " . $_POST["collected_data"][3],
		  'email'  => $_POST["collected_data"][4],
		  'end'    => $_POST["collected_data"][5],
		  'cidade' => $_POST["collected_data"][6],
		  'uf'     => $_POST["collected_data"][7],
		  'cep'    => $_POST["collected_data"][8],
		  'tel'    => $_POST["collected_data"][9]
		  );
	$psg->cliente($cliente);

	$mostra = array("btn_submit" => 0,"print" => false, "open_form" => false,"show_submit" => false);
	$form = $psg->mostra($mostra);
	$itens = $form[1];
	$form = $form[0];

	$_SESSION["pagseguro_id"] = $sessionid;

	//var_dump($GLOBALS);
	?><form id="form_pagseguro" action="https://pagseguro.uol.com.br/security/webpagamentos/webpagto.aspx" method="post">
	<?php echo $form;?>
	<script>window.onload=function(){form_pagseguro.submit();}</script>
	<?php
	//echo $sessionid;
	//var_dump($_SESSION);
	//header("Location: ".$transact_url.$seperator."sessionid=".$sessionid);
	exit();
}

function transact_url()
{
	if(!function_exists("retorno_automatico"))
	{
		define ('TOKEN', get_option("pagseguro_token"));
		function retorno_automatico (
        $VendedorEmail, $TransacaoID, $Referencia, $TipoFrete,
        $ValorFrete, $Anotacao, $DataTransacao, $TipoPagamento,
        $StatusTransacao, $CliNome, $CliEmail, $CliEndereco,
        $CliNumero, $CliComplemento, $CliBairro, $CliCidade,
        $CliEstado, $CliCEP, $CliTelefone, $produtos, $NumItens
      ){

	  global $wpdb;
	  //print $Referencia;
	  //print_r($_POST);
	  //print_r($produtos);
	  //var_dump($_POST);echo "num";
	$wpdb->query($sql);
	switch($StatusTransacao)
	{
	case "Completo":case "Aprovado":
	case "Cancelado":

	break;
	}

	  //Completo && Aprovado
	  //var_dump($StatusTransacao);
	  }
	  //var_dump($_POST);
	require_once("pagseguro/retorno.php");

	}


}

function submit_pagseguro() {
  if($_POST['pagseguro_email'] != null)
    {
    update_option('pagseguro_email', $_POST['pagseguro_email']);
    }
  if($_POST['pagseguro_token'] != null)
    {
    update_option('pagseguro_token', $_POST['pagseguro_token']);
    }
  return true;
}

function form_pagseguro() {
	$output = "<tr>\n\r";
	$output .= "<tr>\n\r";
	$output .= "	<td colspan='2'>\n\r";
	// $output = "	</td>\n\r";
	// $output = "	<td>\n\r";

	//$output .= "<strong>".TXT_WPSC_PAYMENT_INSTRUCTIONS_DESCR.":</strong><br />\n\r";
	$output .= "Email vendedor <input type=\"text\" name=\"pagseguro_email\" value=\"" . get_option('pagseguro_email') . "\"/><br/>\n\r";
	$output .= "TOKEN <input type=\"text\" name=\"pagseguro_token\" value=\"" . get_option('pagseguro_token') . "\"/><br/>\n\r";
	//$output .= "<textarea cols='50' rows='9' name='payment_instructions'>".get_option('payment_instructions')."</textarea><br />\n\r";
	//$output .= "<em>".TXT_WPSC_PAYMENT_INSTRUCTIONS_BELOW_DESCR."</em>\n\r";
	$output .= "	</td>\n\r";
	$output .= "</tr>\n\r";
  return $output;
}
?>
